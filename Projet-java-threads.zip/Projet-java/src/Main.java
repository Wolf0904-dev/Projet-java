public class Main {
    public static void main(String[] args) {
        System.out.println("Projet Java - 4IIR");
    }
}
