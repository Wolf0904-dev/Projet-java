package javaproject;

import java.math.BigDecimal;

public class ThreadGuichet extends Thread {
    private final String nom;
    private final Banque banque;
    private final Compte compte;
    private final BigDecimal montant;
    private final boolean avecPause;

    public ThreadGuichet(String nom, Banque banque, Compte compte, BigDecimal montant, boolean avecPause) {
        this.nom = nom;
        this.banque = banque;
        this.compte = compte;
        this.montant = montant;
        this.avecPause = avecPause;
    }

    @Override
    public void run() {
        for (int i = 1; i <= 5; i++) {
            boolean ok = banque.effectuer(new Versement(compte, montant));
            System.out.println(nom + " → étape " + i + " : versement de " + montant + " DH " + (ok ? "OK" : "REFUSE"));
            if (avecPause) {
                try {
                    Thread.sleep(500);
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    return;
                }
            }
        }
    }

    public String getNom() { return nom; }
}
