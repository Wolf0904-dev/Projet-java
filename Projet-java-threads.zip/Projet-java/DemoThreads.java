package javaproject;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

public class DemoThreads {

    public static void main(String[] args) throws Exception {
        Banque banque = new Banque();
        Guichetier guichetier = new Guichetier("Ali Benani", "ali", "pass123");
        Client client = guichetier.creerClient(banque, "Alami", "Yassine", "AB123456");
        Compte cc = guichetier.ouvrirCompteCourant(banque, client, BigDecimal.valueOf(500));

        exercice1(banque, cc);
        exercice2(banque, guichetier);
        exercice3(banque, guichetier);
    }

    private static void exercice1(Banque banque, Compte cc) throws InterruptedException {
        System.out.println("\n=== EXERCICE 1 : plusieurs guichets sur le même compte ===");
        BigDecimal avant = cc.getSolde();

        ThreadGuichet a = new ThreadGuichet("Guichet A", banque, cc, BigDecimal.valueOf(100), true);
        ThreadGuichet b = new ThreadGuichet("Guichet B", banque, cc, BigDecimal.valueOf(100), true);
        ThreadGuichet c = new ThreadGuichet("Guichet C", banque, cc, BigDecimal.valueOf(100), true);
        a.start();
        b.start();
        c.start();
        a.join();
        b.join();
        c.join();

        System.out.println("Solde avant : " + avant + " | après : " + cc.getSolde() + " (attendu : " + avant.add(BigDecimal.valueOf(1500)) + ")");

        System.out.println("\n--- Sans sleep : les guichets se suivent presque sans alternance ---");
        List<ThreadGuichet> sansPause = new ArrayList<>();
        for (String nom : new String[]{"Guichet A", "Guichet B", "Guichet C"}) {
            sansPause.add(new ThreadGuichet(nom, banque, cc, BigDecimal.valueOf(100), false));
        }
        sansPause.forEach(Thread::start);
        for (ThreadGuichet t : sansPause) t.join();

        System.out.println("\n--- Ordre imposé avec join() : A puis B puis C ---");
        for (String nom : new String[]{"Guichet A", "Guichet B", "Guichet C"}) {
            ThreadGuichet t = new ThreadGuichet(nom, banque, cc, BigDecimal.valueOf(100), false);
            t.start();
            t.join();
        }
        System.out.println("Solde final : " + cc.getSolde());
    }

    private static void exercice2(Banque banque, Guichetier guichetier) throws InterruptedException {
        System.out.println("\n=== EXERCICE 2 : envoi de 10 relevés avec ThreadPoolExecutor(3) ===");
        List<Compte> comptes = new ArrayList<>();
        for (int i = 1; i <= 10; i++) {
            Client cl = guichetier.creerClient(banque, "Client" + i, "Test", "CIN" + i);
            Compte c = guichetier.ouvrirCompteCourant(banque, cl, BigDecimal.valueOf(500));
            guichetier.versement(banque, c, BigDecimal.valueOf(1000L * i));
            comptes.add(c);
        }

        ThreadPoolExecutor executor = (ThreadPoolExecutor) Executors.newFixedThreadPool(3);
        long debut = System.currentTimeMillis();
        for (int i = 0; i < comptes.size(); i++) {
            executor.submit(new TacheNotification(i + 1, comptes.get(i)));
        }
        executor.shutdown();
        executor.awaitTermination(1, TimeUnit.MINUTES);
        System.out.println("Durée totale : " + (System.currentTimeMillis() - debut)
                + " ms (10 tâches de 1 s sur 3 threads ≈ 4 s)");
    }

    private static void exercice3(Banque banque, Guichetier guichetier) throws Exception {
        System.out.println("\n=== EXERCICE 3 : calcul des intérêts de 50 comptes épargne ===");
        List<CompteEpargne> epargnes = new ArrayList<>();
        for (int i = 1; i <= 50; i++) {
            Client cl = guichetier.creerClient(banque, "Epargnant" + i, "Test", "EP" + i);
            CompteEpargne ce = (CompteEpargne) guichetier.ouvrirCompteEpargne(banque, cl, BigDecimal.valueOf(2.5));
            guichetier.versement(banque, ce, BigDecimal.valueOf(1000L * i));
            epargnes.add(ce);
        }

        long t0 = System.currentTimeMillis();
        BigDecimal totalSeq = BigDecimal.ZERO;
        for (CompteEpargne ce : epargnes) totalSeq = totalSeq.add(CalculInterets.calculer(ce));
        long dureeSeq = System.currentTimeMillis() - t0;

        t0 = System.currentTimeMillis();
        List<CalculInterets> threads = new ArrayList<>();
        for (CompteEpargne ce : epargnes) {
            CalculInterets t = new CalculInterets(ce);
            threads.add(t);
            t.start();
        }
        BigDecimal totalThreads = BigDecimal.ZERO;
        for (CalculInterets t : threads) {
            t.join();
            totalThreads = totalThreads.add(t.getInterets());
        }
        long dureeThreads = System.currentTimeMillis() - t0;

        t0 = System.currentTimeMillis();
        ThreadPoolExecutor executor = (ThreadPoolExecutor) Executors.newFixedThreadPool(8);
        List<Future<BigDecimal>> futures = new ArrayList<>();
        for (CompteEpargne ce : epargnes) {
            Callable<BigDecimal> tache = () -> CalculInterets.calculer(ce);
            futures.add(executor.submit(tache));
        }
        BigDecimal totalPool = BigDecimal.ZERO;
        for (Future<BigDecimal> f : futures) {
            try {
                totalPool = totalPool.add(f.get());
            } catch (ExecutionException e) {
                throw new RuntimeException(e.getCause());
            }
        }
        executor.shutdown();
        long dureePool = System.currentTimeMillis() - t0;

        System.out.println("Séquentiel        : " + dureeSeq + " ms | total intérêts = " + totalSeq + " DH");
        System.out.println("50 threads        : " + dureeThreads + " ms | total intérêts = " + totalThreads + " DH");
        System.out.println("Pool de 8 threads : " + dureePool + " ms | total intérêts = " + totalPool + " DH");
    }
}
