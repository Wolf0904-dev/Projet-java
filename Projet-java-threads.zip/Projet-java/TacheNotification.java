package javaproject;

public class TacheNotification implements Runnable {
    private final int id;
    private final Compte compte;

    public TacheNotification(int id, Compte compte) {
        this.id = id;
        this.compte = compte;
    }

    @Override
    public void run() {
        System.out.println("Envoi du relevé n°" + id + " (compte " + compte.getNumero()
                + ", solde " + compte.getSolde() + " DH) par " + Thread.currentThread().getName());
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
}
