package javaproject;

import java.math.BigDecimal;

public class CalculInterets extends Thread {
    private final CompteEpargne compte;
    private BigDecimal interets = BigDecimal.ZERO;

    public CalculInterets(CompteEpargne compte) {
        this.compte = compte;
    }

    @Override
    public void run() {
        interets = calculer(compte);
    }

    public static BigDecimal calculer(CompteEpargne compte) {
        try {
            Thread.sleep(20);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
        return compte.calculerInterets();
    }

    public CompteEpargne getCompte() { return compte; }
    public BigDecimal getInterets() { return interets; }
}
