package javaproject;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

public class TestConcurrence {
    public static void main(String[] args) throws InterruptedException {
        Banque banque = new Banque();
        Guichetier g = new Guichetier("Ali", "ali", "x");
        Client cl = g.creerClient(banque, "A", "B", "T1");
        Compte c1 = g.ouvrirCompteCourant(banque, cl, BigDecimal.ZERO);
        Compte c2 = g.ouvrirCompteCourant(banque, cl, BigDecimal.ZERO);
        c1.crediter(BigDecimal.valueOf(10000));
        c2.crediter(BigDecimal.valueOf(10000));

        List<Thread> ts = new ArrayList<>();
        for (int i = 0; i < 8; i++) {
            final boolean sens = i % 2 == 0;
            Thread t = new Thread(() -> {
                for (int k = 0; k < 2000; k++) {
                    if (sens) new Virement(c1, c2, BigDecimal.ONE).executer();
                    else new Virement(c2, c1, BigDecimal.ONE).executer();
                    c1.crediter(BigDecimal.ONE);
                }
            });
            ts.add(t);
            t.start();
        }
        for (Thread t : ts) t.join();
        System.out.println("Total attendu 20000 + 8*2000 = 36000, obtenu : " + c1.getSolde().add(c2.getSolde()));
    }
}
